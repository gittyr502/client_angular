export class UserKind{
    id:number;
    userKind: string;
    constructor(id:number, userKind: string){
this.id=id;
this.userKind=userKind;
    }
}