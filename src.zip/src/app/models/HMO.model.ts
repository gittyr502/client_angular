export class HMO{
id:number ;
nameOfHMO:string;
constructor(id:number ,nameOfHMO:string){
this.id=id;
this.nameOfHMO=nameOfHMO;
}
}